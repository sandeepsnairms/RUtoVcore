rename export.js.txt to export.js
rename restore.js.txt to restore.js
rename delete_restored_dbs.js.txt to delete_restored_dbs.js

to export 

mongosh "mongodb+srv://uid:pwd@xxxxxx.mongodb.net/?retryWrites=true&w=majority"
load("export.js")


to restore 

mongosh "mongodb+srv://uid:pwd@yyyyyyy.mongocluster.cosmos.azure.com/?tls=true&authMechanism=SCRAM-SHA-256&retrywrites=false&maxIdleTimeMS=120000"
load("restore.js")


to cleanup restored ( only in case you  need to undo the restore)
load("delete_restored_dbs.js")